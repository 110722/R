#' a_cd
#'
#' A dataframe.
#'
#'  @format
#'  A dataframe. 
#'
#'  @name
#'  a_cd
NULL



# readCompoundData <- function(x) {
#   mycompounds <- read.table(x)
#   return(mycompounds)
# }
# 
# 
# basis_dir <- getwd()
# a <- paste(basis_dir, "/inst/extdata/A/A", 1:8, ".txt", sep="")
# a_cd <- readCompoundData(paste(basis_dir, "/inst/extdata/A/Compounds.txt", sep = ""))
# 
# 
# save(file="data/a_cd.rda", list ="a_cd")
