#' a
#'
#' A list containing names of example datasets.
#'
#'  @format
#'  A list of length 8.
#'
#'  @name
#'  a
NULL


# basis_dir <- getwd()
# a <- paste(basis_dir, "/inst/extdata/A/A", 1:8, ".txt", sep="")
# save(file="data/a.rda", list="a")


