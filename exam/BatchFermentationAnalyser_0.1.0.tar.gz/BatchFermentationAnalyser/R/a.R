#' a
#'
#' A list containing names of example datasets.
#'
#'  @format
#'  A list of length 8.
#'
#'  @name
#'  a
NULL


# basis_dir <- getwd()
# input_dir <- paste(basis_dir, "/input/", sep = "")
# output_dir <- paste(basis_dir, "/output/", sep = "")
# a <- paste(input_dir, "inst/extdata/A/A", 1:8, ".txt", sep="")
# save(file="data/a.rda", list="a")


