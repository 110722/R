#' combine_vectors
#'
#' @param x a vector
#' @param y a vector
#'
#' @return combined vector
#' @export
#'
#' @examples
#' combine_vectors(1:5, letters[1:4])
combine_vectors <- function(x, y){
  if (!is.vector(x) | !is.vector(y)){
    return(NA)
  }
  return(c(x,y))
}

