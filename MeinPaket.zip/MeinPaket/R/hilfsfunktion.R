# Diese Funktion ist privat und wird
# nicht im roxygen Format dokumentiert
.MeineHilfsfunktion <- function(x){
  return(2*x)
}

#' benutzeHilfsfunktion
#'
#' @param x ein numerischer Vector
#'
#' @return Das doppelte des Vectors
#' @export
#'
#' @examples
#' benutzeHilfsfunktion(1:10)
benutzeHilfsfunktion <- function(x){
  return(.MeineHilfsfunktion(x))
}