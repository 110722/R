#' MeinPlot
#'
#' @param x A vector
#'
#' @importFrom graphics plot
#'
#' @return plot
#' @export
#'
#' @examples
#' MeinPlot(MeinX)
MeinPlot <- function(x){
  plot(x, col = 2)
}