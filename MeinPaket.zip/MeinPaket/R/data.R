# MeinX <- rnorm(10, mean = 10, sd = 2)
# save(file = "data/daten.rda", list = "MeinX")

#' MeinX
#'
#' An example vector
#'
#' @format vector of length 10
#'
#' @name
#' MeinX
NULL

